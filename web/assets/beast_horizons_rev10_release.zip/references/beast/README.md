# shadow-of-the-beast-html5

 ![PIXI.js](https://img.shields.io/badge/PIXI.js-v8.0.0-blue.svg) [![Netlify Status](https://api.netlify.com/api/v1/badges/ef874f2b-2d7c-4233-ab93-5f28fce45878/deploy-status)](https://app.netlify.com/projects/shadowofthebeast/deploys)

16-bit Amiga classic title demo-scroller remake

**Shadow of the Beast** is a side-scrolling platform video game produced by [Reflections Interactive](https://en.wikipedia.org/wiki/Ubisoft_Reflections) and published by Psygnosis in 1989. The original version was released for the [Commodore Amiga](https://en.wikipedia.org/wiki/Commodore_Amiga), and was later ported to many other systems. Shadow of the Beast is considered revolutionary at the time, because of its graphics, with many more colours on screen and **up to twelve levels of parallax scrolling backdrops**, were of a level rarely if ever seen before in action games.

This is my attempt to recreate the same feeling with HTML5 and [PixiJS](https://www.pixijs.com/).

(source: [Wikipedia](https://en.wikipedia.org/wiki/Shadow_of_the_Beast))

## demo

[https://shadowofthebeast.netlify.app](https://shadowofthebeast.netlify.app)
