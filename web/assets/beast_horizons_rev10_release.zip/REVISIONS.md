# Revision history

| Revision | Description | Preserved location |
|---|---|---|
| 01 | Original Temple Tides: solid colors, opaque architecture, approximately 30 updates/s | `revisions/rev01/` |
| 02 | Aqueduct Tides: Sierra Lite clouds and shaded terrain; transparent aqueduct over fixed valley; approximately 20 updates/s | `revisions/rev02/` |
| 03 | One fixed mountain landscape; drifting clouds; trees moving through arches; animated wave crests and sun reflection; approximately 20 updates/s | `revisions/rev03/` |

Rev 01 DCK SHA-256: `6189d1428b3715357149799fcba8f6e583754bd886f6d4e1f19d0134d760b74e`.

Rev 02 DCK SHA-256: `cf1e0cf3885406178009d4f923e996b61977d0091ed5c27cfa9a25327f4ff3e2`.

Rev 03 DCK SHA-256: `169141d0a2e459a704dbeca8cc7ab1a46b181fd8d4f68647c83989bfb1a3fc6d`.

All passed cold cartridge boot, display initialization, custom interrupts,
and 1,024+ animation updates in the TS2068 emulator tests. None is tested
on physical hardware. Every future accepted revision must be preserved before
the next revision is developed; see `AGENTS.md`.

## Revision 04

Preserved in `revisions/rev04/`: QAOP speedboat and speed-dependent aqueduct,
palm and slow mountain parallax; fixed sunset gradient; colorful terrain;
calmer water and speed-dependent wake. Approximately 15 updates/s.

DCK SHA-256: `62412810f59d76e2b6bd1b4632f9b8cf179dc919f7abe11ff7a9d0eeb7c29be5`.

Passed 1,025 TSRun updates with keyboard control and pixel-reference checks;
Fuse boot/interrupt/1,024-update checks; maximum-throttle sampled timing
230,081 T-states within 238,944; independent DCK expansion comparison.
Keyboard only; no physical hardware test. Revisions 01–03 remain unchanged.

## Revision 05

Preserved in `revisions/rev05/`: larger right-facing speedboat, Q/A vertical
movement, O/P throttle, medium-speed hull centering and speed-dependent
horizontal position. Fine water ripples scroll left at twice aqueduct speed.
Three animated white spray poses trail the stern. Linear-light adaptive
Sierra Lite conversion gives the fixed sky a softer gradient.

DCK SHA-256: `e4557f804363845168fbc635c2636efacf1f3ba29a910bb6b9474dd9a50423f8`.

Passed 1,025 TSRun updates with keyboard input and complete pixel/attribute
reference comparisons; Fuse cold boot, interrupt and 1,024-update checks;
maximum-throttle sampled cost 224,910 T-states within the 238,944 budget;
independent cartridge expansion comparison. Approximately 15 updates/s.
Earlier revision checksums verified intact; physical hardware remains untested.

## Revision 06 — Beast Horizons

Shadow of the Beast scenery/runner cartridge, preserved in `revisions/rev06/`.
Five cloud speeds, a slow surreal rock landscape, pink Sierra Lite sky,
five thin grass bands and a foreground fence/stone strip. Six blue/white
running poses are adapted from the user-supplied HTML5 reference; source
assets and attribution are included. O/P controls running speed and stopping.

The 256×48 runner strip is completely composed in RAM, including attributes,
before any byte in that strip reaches the display. Four prepared ECM phases
provide 2-pixel scrolling. Approximately 12 updates/s (five refreshes).

DCK SHA-256: `bc152c2144911a4cb371a927715f60cb92dc9adeb188447e73c696f41fdfd12c`.

Passed 1,025 TSRun updates with complete pixel/attribute and buffer checks,
including assertions against visible erase/draw writes, controls and bank/cache
integrity. Fuse passed boot, interrupt and update-1,024 checks. A separate
256-update maximum-speed timing run peaked at 294,567 T-states, below the
298,680 budget. Hardware raster tearing and physical-machine operation remain
untested. Previous revision archives are unchanged.

## Revision 07 — Single-pixel rocks

Preserved in `revisions/rev07/`. The distant rock layer now advances exactly
one pixel every eight updates (about 1.5 pixels/second), stopping at zero
running speed. Eight prepared phases replace the old four-phase rock layer.
Shared bitmap/attribute strips keep the same 64 KB ROM capacity. The buffered
character and the other parallax layers retain their existing behavior.

DCK SHA-256: `2a8f84f44a577329fcf3945c49a70c4ec4ab29f72e7661b5a9180280791a5e71`.

Passed 2,305 TSRun updates with exact display/buffer comparisons and explicit
one-pixel step assertions across all 256 rock positions, including wrap.
Fuse boot/interrupt/update-1,024 checks and 256 maximum-speed timing samples
passed: peak 296,114 T-states within 298,680. Approximately 12 updates/s.
Revision 06 was checksum-verified before editing and remains unchanged.

## Revision 08 — Faster rocks, stable shading

Preserved in `revisions/rev08/`. Rocks move in one-pixel steps across the screen

in 10.82 seconds in Fuse and 10.67 seconds in TSRun. Rose scanline palettes

remove rock cell-color boundaries; rigidly shifted Sierra Lite patterns remove

phase-dependent texture crawl. Grass palettes are fixed per row and the fence

is black/white to save attribute traffic. Clouds retain revision 07 artwork.

Runner/ground updates alternate with rock-only updates, retaining RAM composition.

DCK SHA-256: `ea6d6dee7794ed11fc2497f486b434bedd23f5628e45236720153a318a4b1425`.

Passed 2,305 TSRun exact display/buffer checks, one-pixel/wrap/rigid-dither checks,

controls, protected display writes and cache/bank integrity. Fuse passed boot,

interrupt and update-1,024 checks plus 256 maximum-speed timing samples:

peak 168,711 T-states below 179,208. Independent DCK inspection matches ROM payload.

Physical hardware and live raster tearing remain untested. Revision 07 preserved.

## Revision 09 - Native AY title music

Preserved in `revisions/rev09/`. The supplied David Whittaker title tune plays
automatically at approximately 50 Hz through TS2068 ports FFF5/FFF6, and repeats
after its declared 5,450 ticks. The source driver runs at its original addresses
in HOME RAM. Music continues when the runner stops. Revision-08 artwork remains
byte-identical; only the four character columns are now buffered, eliminating
redundant full-width copies to recover time for music.

DCK SHA-256: `ac1b31362b696de8613eaf55a065ea9b49534afb6a0fa9533b83b22658db796a`.

TSRun passed 2,305 exact display / character-buffer checks and 12,000 music ticks
against the unmodified driver with the documented restart schedule (two song
restarts). Fuse passed boot/interrupt/update-1,024 checks, 1,000 music ticks /
10,996 exact register writes, and a 6,000-update maximum-speed timing run.
Peak rendering including audio interrupts: 166,787 T-states, below 179,208.
Rock screen transit: 10.68 seconds over the first 256 updates, 10.67 seconds
averaged over the long run. All movement remains single-pixel. DCK payload and
archive checksums were verified. Physical hardware and live raster tearing
remain untested. Revision 08 remains unchanged.

## Revision 10 - S-key sound toggle and player credit

Preserved in `revisions/rev10/`. S toggles sound off/on, default on. A held key
produces one toggle until released. Muting forces all three AY amplitude registers
to zero while keeping their intended values in RAM; driver timing, envelopes,
tune position and looping continue. Re-enabling restores the current levels.
Josef Jelinek is credited for the TS2068 AY player from his TS2068.groups.io post
"A new TS 2068 AY music composer preview," used as the native-port reference.

DCK SHA-256: `fecc762d6c38476da647f0eccc5b2c1d752b2a81d9d36397e17574b50e796331`.

Passed 2,305 TSRun exact display/buffer checks; 12,000 default-on music ticks
plus a separate 12,000-tick S-key test covering four toggles, held keys, immediate
three-channel muting/restoration and a tune restart while muted. Fuse passed
boot/interrupt/update-1,024, 1,000 music ticks / 10,996 reference writes and 6,000
maximum-speed animation updates. Peak render interval: 173,475 T-states below
179,208. Rocks cross in 10.68 seconds, or 10.67 averaged over the long run.
Revision 09 remains unchanged. Physical hardware remains untested.
