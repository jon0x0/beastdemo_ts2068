# Revision preservation

The user requires every accepted revision to remain available for comparison.
Before changing an accepted revision, archive its source, build artifacts,
documentation, previews, and validation evidence in `revisions/revNN/`.
Never overwrite a populated revision directory. Record revision changes and
test status in `REVISIONS.md`. `build/` is the current working build only.
